package com.codegym.c0324h1_spring_boot_2.services;

import com.codegym.c0324h1_spring_boot_2.models.Classroom;

import java.util.List;

public interface IClassroomService {

    List<Classroom> getAllClassrooms();
}
